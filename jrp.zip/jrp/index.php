<?php session_start();if(!empty($_SESSION['uid'])){header('Location: dashboard.php');exit;}?>
<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login - Jasa Raharja Putera</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"><link rel="stylesheet" href="assets/style.css"></head>
<body class="login-body"><div class="login-card">
<div class="login-left"><div class="brand"><img src="assets/logo.jpeg" alt=""><span>jasa raharja putera<br>insurance</span></div>
<div class="welcome"><h1>Selamat Datang<br>di Jasa Raharja Putera</h1><p>Kelola data asuransi dengan mudah,<br>cepat dan aman.</p><hr></div>
<div class="trust"><i class="fa-solid fa-shield-halved"></i> Terpercaya • Profesional • Melayani</div></div>
<div class="login-right"><img class="logo-big" src="assets/logo.jpeg" alt=""><h2>Login ke Akun Anda</h2><p class="sub">Masuk untuk melanjutkan ke dashboard</p>
<div id="err" class="err"></div>
<div class="field"><i class="fa-solid fa-user"></i><input id="u" placeholder="Username" autocomplete="username"></div>
<div class="field"><i class="fa-solid fa-lock"></i><input id="p" type="password" placeholder="Password" autocomplete="current-password"><i class="fa-regular fa-eye-slash eye" id="eye"></i></div>
<div class="row"><label><input type="checkbox"> Ingat saya</label><a href="#">Lupa password?</a></div>
<button class="btn-login" id="go">Login <i class="fa-solid fa-arrow-right"></i></button>
<div class="copy">© 2026 Jasa Raharja Putera Insurance</div></div></div>
<script>
const $=i=>document.getElementById(i);
$('eye').onclick=()=>{const h=$('p').type==='password';$('p').type=h?'text':'password';$('eye').className='eye fa-regular '+(h?'fa-eye':'fa-eye-slash')};
async function login(){
  const r=await fetch('api.php?a=login',{method:'POST',body:JSON.stringify({username:$('u').value,password:$('p').value})});
  const d=await r.json();
  if(d.ok)location='dashboard.php';else{$('err').textContent='Login gagal: '+d.error;$('err').style.display='block'}
}
$('go').onclick=login;document.addEventListener('keydown',e=>e.key==='Enter'&&login());
</script></body></html>
