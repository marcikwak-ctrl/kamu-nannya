CREATE DATABASE IF NOT EXISTS jrp_db CHARACTER SET utf8mb4;
USE jrp_db;
CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(100) NOT NULL,username VARCHAR(50) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL);
CREATE TABLE IF NOT EXISTS produk(
 id_produk INT AUTO_INCREMENT PRIMARY KEY,produk VARCHAR(30) NOT NULL,no_polis VARCHAR(60) NOT NULL,
 nama_tertanggung VARCHAR(120) NOT NULL,periode_mulai DATE NOT NULL,periode_berakhir DATE NOT NULL,
 nomor_kotak VARCHAR(20) NOT NULL,nomor_lemari VARCHAR(20) NOT NULL,status ENUM('OPEN','CLOSE') NOT NULL DEFAULT 'OPEN',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP);
INSERT INTO users(nama,username,password) VALUES('Admin JRP','Admin','$2y$12$m27R1P2xm2TmUDd1rVNGB.22o6fG8OZzGvOPwOmx.ka/nX40O6yCe');
INSERT INTO produk(produk,no_polis,nama_tertanggung,periode_mulai,periode_berakhir,nomor_kotak,nomor_lemari,status) VALUES
('Kendaraan','JRP/KND/2024/001234','Budi Santoso','2024-01-01','2024-12-31','A01','L01','CLOSE'),
('Kendaraan','014204','RITA BAYANI','2026-01-01','2026-12-31','A02','L01','OPEN'),
('Kebakaran','005775','PT PERSADA SAWIT MAS','2025-05-20','2026-05-20','B01','L02','CLOSE'),
('Gempa','021148','PT KARYA MAJU UTAMA','2026-06-18','2027-06-18','C01','L03','OPEN'),
('PAR','020540','CV Omega MotorSport','2027-01-01','2027-12-31','D01','L04','OPEN');
-- Cek periode otomatis setiap hari (butuh event_scheduler=ON). Tanpa ini, api.php tetap menutup otomatis saat dibuka.
CREATE EVENT IF NOT EXISTS ev_cek_periode ON SCHEDULE EVERY 1 DAY STARTS CURRENT_DATE + INTERVAL 1 DAY
DO UPDATE produk SET status='CLOSE' WHERE periode_berakhir<CURDATE() AND status='OPEN';
