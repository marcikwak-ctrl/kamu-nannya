<?php
require 'config.php';
header('Content-Type: application/json');
$in=json_decode(file_get_contents('php://input'),true)?:[];
$a=$_GET['a']??'';
function out($d,$c=200){http_response_code($c);echo json_encode($d);exit;}
if($a==='login'){
  $s=$db->prepare('SELECT * FROM users WHERE username=?');$s->execute([trim($in['username']??'')]);$u=$s->fetch();
  if($u&&password_verify($in['password']??'',$u['password'])){session_regenerate_id(true);$_SESSION['uid']=$u['id'];$_SESSION['nama']=$u['nama'];out(['ok'=>1]);}
  out(['error'=>'Username atau password salah'],401);
}
if(empty($_SESSION['uid']))out(['error'=>'Sesi habis'],401);
// Cek periode otomatis: periode berakhir lewat => CLOSE
$db->exec("UPDATE produk SET status='CLOSE' WHERE periode_berakhir<CURDATE() AND status='OPEN'");
if($a==='list'){
  $p=max(1,(int)($_GET['page']??1));$w='1=1';$v=[];
  if(!empty($_GET['k'])){$w.=' AND produk=?';$v[]=$_GET['k'];}
  if(!empty($_GET['q'])){$w.=' AND (no_polis LIKE ? OR nama_tertanggung LIKE ?)';$v[]=$v[]='%'.$_GET['q'].'%';}
  $s=$db->prepare("SELECT COUNT(*) c FROM produk WHERE $w");$s->execute($v);$total=(int)$s->fetch()['c'];
  $off=($p-1)*12;$s=$db->prepare("SELECT * FROM produk WHERE $w ORDER BY id_produk DESC LIMIT 12 OFFSET $off");$s->execute($v);
  $st=$db->query("SELECT COALESCE(SUM(status='OPEN' AND periode_mulai<=CURDATE()),0) aktif,COALESCE(SUM(status='OPEN' AND periode_mulai>CURDATE()),0) segera,COALESCE(SUM(status='CLOSE'),0) non FROM produk")->fetch();
  $cats=$db->query('SELECT produk,COUNT(*) c FROM produk GROUP BY produk')->fetchAll(PDO::FETCH_KEY_PAIR);
  out(['items'=>$s->fetchAll(),'total'=>$total,'stats'=>$st,'cats'=>$cats,'today'=>date('Y-m-d')]);
}
if($a==='get'){$s=$db->prepare('SELECT * FROM produk WHERE id_produk=?');$s->execute([(int)$_GET['id']]);out($s->fetch()?:['error'=>'Tidak ditemukan']);}
if($a==='save'){
  foreach(['produk','no_polis','nama_tertanggung','periode_mulai','periode_berakhir','nomor_kotak','nomor_lemari'] as $f)if(trim($in[$f]??'')==='')out(['error'=>'Data belum lengkap'],422);
  if($in['periode_mulai']>$in['periode_berakhir'])out(['error'=>'Periode berakhir harus setelah periode mulai'],422);
  $st=$in['periode_berakhir']<date('Y-m-d')?'CLOSE':'OPEN';
  $d=[$in['produk'],trim($in['no_polis']),trim($in['nama_tertanggung']),$in['periode_mulai'],$in['periode_berakhir'],trim($in['nomor_kotak']),trim($in['nomor_lemari']),$st];
  if(!empty($in['id'])){$d[]=(int)$in['id'];$db->prepare('UPDATE produk SET produk=?,no_polis=?,nama_tertanggung=?,periode_mulai=?,periode_berakhir=?,nomor_kotak=?,nomor_lemari=?,status=? WHERE id_produk=?')->execute($d);}
  else $db->prepare('INSERT INTO produk(produk,no_polis,nama_tertanggung,periode_mulai,periode_berakhir,nomor_kotak,nomor_lemari,status) VALUES(?,?,?,?,?,?,?,?)')->execute($d);
  out(['ok'=>1]);
}
if($a==='delete'){$db->prepare('DELETE FROM produk WHERE id_produk=?')->execute([(int)($in['id']??0)]);out(['ok'=>1]);}
out(['error'=>'Aksi tidak dikenal'],400);
