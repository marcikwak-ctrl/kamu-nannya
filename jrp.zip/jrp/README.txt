INSTALASI (XAMPP/Laragon)
1. Salin folder "jrp" ke htdocs (XAMPP) atau www (Laragon).
2. Buka phpMyAdmin > Import > pilih database.sql (membuat database jrp_db, tabel, dan user Admin).
3. Sesuaikan user/password MySQL di config.php bila perlu (default root, tanpa password).
4. Buka http://localhost/jrp/  Login: Admin / Admin#1234
Cek periode otomatis: api.php menutup data yang periodenya lewat setiap kali diakses, dan MySQL EVENT harian di database.sql menjalankannya terjadwal (aktifkan: SET GLOBAL event_scheduler=ON;).
