const $=i=>document.getElementById(i);
const CATS=[['Kendaraan','fa-car'],['Kebakaran','fa-fire'],['Gempa','fa-house-crack'],['PAR','fa-building-shield'],['Varia','fa-cube'],['BPJS','fa-shield-heart']];
const ICON=Object.fromEntries(CATS);
let S={k:'',q:'',page:1,today:''};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=d=>{const[y,m,t]=d.split('-');return `${t}/${m}/${y}`};
const fmtL=d=>{const M=['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];const[y,m,t]=d.split('-');return `${t} ${M[m-1]} ${y}`};
const st=p=>p.status==='CLOSE'?['non','n','Nonaktif']:(p.periode_mulai>S.today?['seg','s','Segera Aktif']:['','a','Aktif']);
async function api(a,body,qs=''){const r=await fetch(`api.php?a=${a}${qs}`,body?{method:'POST',body:JSON.stringify(body)}:{});if(r.status===401)location='index.php';return r.json()}
async function load(){
  const d=await api('list',0,`&page=${S.page}&k=${encodeURIComponent(S.k)}&q=${encodeURIComponent(S.q)}`);
  S.today=d.today;$('sA').textContent=d.stats.aktif;$('sS').textContent=d.stats.segera;$('sN').textContent=d.stats.non;
  $('cats').innerHTML=CATS.map(([n,i])=>`<div class="cat ${S.k===n?'on':''}" data-k="${n}"><i class="fa-solid ${i}"></i>${n}${S.k===n?`<span>${d.cats[n]||0}</span>`:''}</div>`).join('');
  document.querySelectorAll('.cat').forEach(e=>e.onclick=()=>{S.k=S.k===e.dataset.k?'':e.dataset.k;S.page=1;load()});
  $('grid').innerHTML=d.items.length?d.items.map(p=>{const[c,t,l]=st(p);return `<div class="card ${c}" data-id="${p.id_produk}">
   <div class="dots">•••</div><div class="ic"><i class="fa-regular fa-file-lines"></i><div class="av"><i class="fa-solid fa-user"></i></div></div>
   <div class="no">${esc(p.no_polis)} <span class="tag ${t}">${l}</span></div><div class="nm">${esc(p.nama_tertanggung)}</div>
   <div class="pr">${esc(p.produk)}</div>
   <div class="meta"><i class="fa-regular fa-calendar"></i> Created: ${p.created_at}<br><i class="fa-solid fa-rotate"></i> Updated: ${p.updated_at}</div>
   <div class="act"><button class="ed" title="Edit"><i class="fa-regular fa-pen-to-square"></i></button><button class="del" title="Hapus"><i class="fa-regular fa-trash-can"></i></button></div></div>`}).join(''):'<div class="empty">Data tidak ditemukan. Klik Tambah Data untuk membuat data baru.</div>';
  document.querySelectorAll('.card').forEach(e=>{const id=e.dataset.id;e.onclick=()=>detail(id);e.querySelector('.ed').onclick=x=>{x.stopPropagation();form(id)};e.querySelector('.del').onclick=x=>{x.stopPropagation();hapus(id)}});
  const n=Math.max(1,Math.ceil(d.total/12)),a=d.total?(S.page-1)*12+1:0,b=Math.min(S.page*12,d.total);
  $('info').textContent=`Menampilkan ${a} – ${b} dari ${d.total} data`;
  let h=`<button data-p="${Math.max(1,S.page-1)}"><i class="fa-solid fa-chevron-left"></i></button>`;
  for(let i=1;i<=n;i++)h+=`<button class="${i===S.page?'on':''}" data-p="${i}">${i}</button>`;
  $('pages').innerHTML=h+`<button data-p="${Math.min(n,S.page+1)}"><i class="fa-solid fa-chevron-right"></i></button>`;
  document.querySelectorAll('#pages button').forEach(e=>e.onclick=()=>{S.page=+e.dataset.p;load()});
}
const open=h=>{$('modal').innerHTML=h;$('ov').classList.add('show')},close=()=>$('ov').classList.remove('show');
const head=t=>`<div class="mh"><img src="assets/logo.jpeg" alt="">${t}<button class="x" onclick="close_()">✕</button></div>`;
window.close_=close;$('ov').onclick=e=>e.target.id==='ov'&&close();
async function detail(id){
  const p=await api('get',0,'&id='+id),[,t,l]=st(p),i=ICON[p.produk]||'fa-car';
  open(head('Detail Produk')+`<div class="mb"><div class="mside"><i class="fa-solid ${i}"></i><span>${esc(p.produk)}</span></div><div class="mc"><div class="dl">
  <i class="fa-solid ${i}"></i><b>Produk</b><span>: ${esc(p.produk)}</span><i class="fa-solid fa-file-signature"></i><b>No Polis</b><span>: ${esc(p.no_polis)}</span>
  <i class="fa-regular fa-user"></i><b>Nama Tertanggung</b><span>: ${esc(p.nama_tertanggung)}</span><i class="fa-regular fa-calendar"></i><b>Periode</b><span>: ${fmtL(p.periode_mulai)} – ${fmtL(p.periode_berakhir)}</span>
  <i class="fa-solid fa-box-archive"></i><b>Nomor Kotak</b><span>: ${esc(p.nomor_kotak)}</span><i class="fa-solid fa-cabinet-filing"></i><b>Nomor Lemari</b><span>: ${esc(p.nomor_lemari)}</span>
  <i class="fa-solid fa-shield-halved"></i><b>Status</b><span class="badge ${t}"><i class="fa-solid fa-circle-check"></i>${l}</span></div></div></div>
  <div class="mf"><button class="bp" onclick="close_()">✕ Tutup</button></div>`);
}
async function form(id){
  const p=id?await api('get',0,'&id='+id):{produk:S.k||'Kendaraan',no_polis:'',nama_tertanggung:'',periode_mulai:'',periode_berakhir:'',nomor_kotak:'',nomor_lemari:''};
  open(head(id?'Edit Data Produk':'Tambah Data Produk')+`<div class="mb"><div class="mside"><i class="fa-solid ${ICON[p.produk]||'fa-car'}" id="fi"></i><span id="fl">${esc(p.produk)}</span></div><div class="mc"><div class="fg">
  <div><label>Produk <em>*</em></label><select id="f_produk">${CATS.map(([n])=>`<option ${n===p.produk?'selected':''}>${n}</option>`).join('')}</select></div>
  <div><label>Periode Mulai <em>*</em></label><input type="date" id="f_periode_mulai" value="${p.periode_mulai}"></div>
  <div><label>No Polis <em>*</em></label><input id="f_no_polis" value="${esc(p.no_polis)}"></div>
  <div><label>Periode Berakhir <em>*</em></label><input type="date" id="f_periode_berakhir" value="${p.periode_berakhir}"></div>
  <div><label>Nama Tertanggung <em>*</em></label><input id="f_nama_tertanggung" value="${esc(p.nama_tertanggung)}"></div>
  <div class="two"><div><label>Nomor Kotak <em>*</em></label><input id="f_nomor_kotak" value="${esc(p.nomor_kotak)}"></div><div><label>Nomor Lemari <em>*</em></label><input id="f_nomor_lemari" value="${esc(p.nomor_lemari)}"></div></div></div>
  <div class="ferr" id="ferr"></div></div></div><div class="mf"><button class="bs" onclick="close_()">✕ Batal</button><button class="bp" id="sv"><i class="fa-regular fa-floppy-disk"></i> Simpan Perubahan</button></div>`);
  $('f_produk').onchange=e=>{$('fi').className='fa-solid '+ICON[e.target.value];$('fl').textContent=e.target.value};
  $('sv').onclick=async()=>{
    const b={id};['produk','no_polis','nama_tertanggung','periode_mulai','periode_berakhir','nomor_kotak','nomor_lemari'].forEach(k=>b[k]=$('f_'+k).value);
    const r=await api('save',b);if(r.ok){close();load()}else $('ferr').textContent=r.error;
  };
}
function hapus(id){
  open(`<div class="del-m"><div class="bin"><i class="fa-solid fa-trash"></i></div><h3>Hapus Data?</h3><p>Apakah Anda yakin ingin menghapus data ini? Tindakan ini tidak dapat dibatalkan.</p>
  <div class="bt"><button class="bs" onclick="close_()">Batal</button><button class="bp" style="background:#e53935" id="yes">Hapus</button></div></div>`);
  $('yes').onclick=async()=>{await api('delete',{id});close();load()};
}
let tm;$('q').oninput=e=>{clearTimeout(tm);tm=setTimeout(()=>{S.q=e.target.value;S.page=1;load()},300)};
$('add').onclick=()=>form(null);load();
