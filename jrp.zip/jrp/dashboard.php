<?php require 'config.php';if(empty($_SESSION['uid'])){header('Location: index.php');exit;}?>
<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Data Produk - Jasa Raharja Putera</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"><link rel="stylesheet" href="assets/style.css"></head>
<body><aside class="side"><div class="brand"><img src="assets/logo.jpeg" alt=""><span>Jasa Raharja Putera<br>Insurance</span></div>
<nav class="menu"><h4>PRODUK KATEGORI</h4><div id="cats"></div><hr><a href="#"><i class="fa-solid fa-gear"></i> Pengaturan</a><a href="logout.php"><i class="fa-solid fa-moon"></i> Keluar</a></nav>
<a class="out" href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a></aside>
<main><header class="top"><div class="search"><i class="fa-solid fa-magnifying-glass"></i><input id="q" placeholder="Cari No Polis, Nama Tertanggung..."></div>
<div class="bell"><i class="fa-regular fa-bell"></i><b></b></div><div class="me"><i class="fa-solid fa-user"></i> <?=htmlspecialchars($_SESSION['nama']?:'Admin')?> <i class="fa-solid fa-chevron-down"></i></div></header>
<section class="head"><div><h1>Data Produk</h1><p>Kelola data produk dan status fitur</p></div>
<div class="stats"><div class="st g"><i class="fa-solid fa-check"></i><div><small>Aktif</small><b id="sA">0</b><small>Produk</small></div></div>
<div class="st y"><i class="fa-solid fa-play"></i><div><small>Segera Aktif</small><b id="sS">0</b><small>Produk</small></div></div>
<div class="st n"><i class="fa-solid fa-pause"></i><div><small>Non Aktif</small><b id="sN">0</b><small>Produk</small></div></div>
<button class="btn-add" id="add"><i class="fa-solid fa-plus"></i> Tambah Data</button></div></section>
<div class="grid" id="grid"></div>
<footer class="pg"><span id="info"></span><div id="pages"></div></footer></main>
<div class="ov" id="ov"><div class="modal" id="modal"></div></div>
<script src="assets/app.js"></script></body></html>
